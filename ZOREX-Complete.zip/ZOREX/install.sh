#!/bin/bash
# ZOREX - Dependency Installer
# Run: chmod +x install.sh && sudo ./install.sh

echo "[+] Installing ZOREX Dependencies..."

# System packages
sudo apt update
sudo apt install -y aircrack-ng hashcat reaver hcxdumptool hcxtools hostapd dnsmasq php

# Python package
pip3 install netifaces --break-system-packages 2>/dev/null || pip3 install netifaces

# Wordlist
sudo gunzip /usr/share/wordlists/rockyou.txt.gz 2>/dev/null

echo "[+] Done! Run: sudo python3 zorex.py"
