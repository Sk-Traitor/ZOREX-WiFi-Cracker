# 🔥 ZOREX - Advanced Wireless Penetration Testing Framework

[![Version](https://img.shields.io/badge/version-3.0.0-red.svg)]()
[![License](https://img.shields.io/badge/license-MIT-blue.svg)]()
[![Python](https://img.shields.io/badge/python-3.8+-green.svg)]()

**ZOREX** is a professional-grade wireless penetration testing framework for security researchers and ethical hackers. It automates WPA2/WPA3 attacks including handshake capture, evil twin, and automated cracking.

---

## 📸 Screenshots

<p align="center">
  <img src="screenshots/menu.png" width="45%" />
  <img src="screenshots/autopwn.png" width="45%" />
</p>

---

## ⚡ Features

| Category | Features |
|----------|----------|
| **Scanning** | WPA2/WPA3 detection, Client tracking, Signal analysis |
| **Attacks** | Deauth, Handshake capture, PMKID, WPS Pixie Dust |
| **Advanced** | Evil Twin, GPU Cracking, Auto Pwn Mode |
| **Reporting** | Professional HTML reports, Session management |

---

## 🛠️ Installation

### One-Line Install

```bash
git clone https://github.com/YOUR_USERNAME/ZOREX.git
cd ZOREX
chmod +x install.sh && sudo ./install.sh
